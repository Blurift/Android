package com.game.ECS.Components;

import com.badlogic.gdx.math.Vector2;

/**
 * Created by Sean on 28/04/2015.
 */
public class DirectionComponent {
    Vector2 dir = new Vector2(0,0);
}
