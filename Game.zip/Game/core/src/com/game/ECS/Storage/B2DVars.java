package com.game.ECS.Storage;

/**
 * Created by Sean on 22/04/2015.
 */
public class B2DVars {

    //Categories
    public static final short BIT_COLLISION = 0x0001;
    public static final short BIT_PROJECTILE = 0x0002;
    public static final short BIT_HUSK = 0x0004;
    public static final short BIT_HITBOX = 0x0008;
    public static final short BIT_CONSUMABLE = 0x0010;
}
