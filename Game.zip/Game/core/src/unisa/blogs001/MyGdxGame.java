
package unisa.blogs001;



import java.util.Iterator;

import com.badlogic.gdx.ApplicationListener;


public class MyGdxGame implements ApplicationListener {

    @Override
    public void create() {
    }

    private void spawnRaindrop() {
    }

    @Override
    public void render() {
    }

    @Override
    public void dispose() {
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }
}